// Tecnologias que o Breno domina, agrupadas. Nada entra por suposição:
// preencher apenas depois que ele confirmar item a item (TODO_STACK_CONFIRMADA).
export interface GrupoStack {
  nome: 'Front-end' | 'Back-end' | 'Banco' | 'Ferramentas' | 'Estudando agora';
  itens: string[];
}

export const PENDENCIA_STACK = 'TODO_STACK_CONFIRMADA';

export const grupos: GrupoStack[] = [];
