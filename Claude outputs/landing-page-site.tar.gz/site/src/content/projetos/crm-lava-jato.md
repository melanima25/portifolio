---
titulo: 'CRM Lava Jato — TZ Auto Estética'
resumo: 'Sistema de gestão para um lava jato real: TODO_RESUMO_FUNCIONALIDADES'
status: producao
destaque: true
ordem: 1
stack: [] # TODO_STACK_CRM
cliente: 'TZ Auto Estética'
# links.demo: TODO_URL_DEMO_CRM
# Repositório PRIVADO: não exibir link de código.
usoDeIA: 'Desenvolvido com apoio de agentes de IA, com revisão de cada entrega.'
---

### O problema

TODO_PROBLEMA

### Decisões técnicas

TODO_DECISOES

### Como usei IA

Desenvolvi o sistema com apoio de agentes de IA, revisando e entendendo cada parte do que foi entregue.

### Resultado

TODO_RESULTADO

Métricas: TODO_METRICA

### Próximos passos

Versão multiusuário (CRM v2).
