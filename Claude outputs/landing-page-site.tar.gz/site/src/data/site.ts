// Dados do site. Tudo que o Breno ainda não forneceu fica como TODO_* (ver README).
export const site = {
  nome: 'Breno Ferreira',
  cargo: 'Desenvolvedor Júnior',
  titulo: 'Breno Ferreira — Desenvolvedor Júnior | Portfólio',
  descricao:
    'Portfólio de Breno Ferreira, desenvolvedor júnior: sistemas web para pequenos negócios, com um CRM já em produção. Aberto a vagas remotas.',
  email: 'brenojf19@gmail.com',
  linkedin: 'https://www.linkedin.com/in/breno-ferreira-928340385/',
  // Perfil público ainda não confirmado pelo Breno.
  github: 'TODO_GITHUB_PROFILE',
  repoPortfolio: 'TODO_URL_REPO_PORTFOLIO',
  // Opcional: caminho do PDF em /public (ex.: '/cv-breno.pdf'). Sem valor, o botão "Baixar CV" some.
  cv: undefined as string | undefined,
  ogImage: 'TODO_OG_IMAGE',
} as const;

export const navLinks = [
  { href: '#projetos', rotulo: 'Projetos' },
  { href: '#sobre', rotulo: 'Sobre' },
  { href: '#stack', rotulo: 'Stack' },
  { href: '#contato', rotulo: 'Contato' },
] as const;
