// Pendências por projeto (campos que ainda não temos). Mantém o frontmatter válido
// (links omitidos) e torna o que falta visível no build de desenvolvimento.
// O CRM tem repositório PRIVADO: nunca exibir botão/link de código.
export const pendenciasPorProjeto: Record<
  string,
  { stack?: string; demo?: string; metricas?: string }
> = {
  'crm-lava-jato': {
    stack: 'TODO_STACK_CRM',
    demo: 'TODO_URL_DEMO_CRM',
    metricas: 'TODO_METRICA',
  },
};
