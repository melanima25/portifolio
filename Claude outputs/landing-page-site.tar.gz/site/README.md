# Portfólio — Breno Ferreira

Landing page estática de portfólio (Astro 5 + TypeScript strict + Tailwind v4). Decisões, tokens e
checklists estão em [`../docs/ARQUITETURA.md`](../docs/ARQUITETURA.md).

## Como rodar

```bash
cd site
npm install
npm run dev          # servidor de desenvolvimento
npm run build        # build de desenvolvimento: passa, mas lista as pendências TODO_*
npm run build:prod   # build estrito: FALHA se sobrar qualquer TODO_* (exige SITE_URL)
npm run preview      # serve o dist/
npm run typecheck    # astro check
npm run lint         # eslint
```

Para o build de produção: `SITE_URL=https://seu-dominio npm run build:prod` (veja `.env.example`).

## Estrutura

- `src/pages` — `index.astro` (página única) e `404.astro`
- `src/components/{layout,sections,ui}` — componentes Astro (0 KB de JS por padrão)
- `src/components/react/ThemeToggle.tsx` — única ilha React (`client:idle`)
- `src/content/projetos/*.md` — content collection; **adicionar projeto = criar 1 arquivo** (schema em `src/content.config.ts`)
- `src/data/` — `site.ts` (links/contato), `stack.ts`, `pendencias.ts`
- `src/styles/global.css` — tokens (cores, tipografia, tema claro/escuro)
- `public/_headers`, `wrangler.toml` — configuração do Cloudflare Pages
- `../.github/workflows/ci.yml` — CI (lint, typecheck, build; main = build estrito + Lighthouse)

## Como funcionam as pendências

Tudo que ainda não temos fica como `TODO_*`. No build normal aparece como etiqueta tracejada
"pendente: TODO_X" na página e é listado no terminal. No `build:prod` qualquer pendência derruba o
build, então placeholders nunca chegam à produção.

## O que falta preencher

- `TODO_GITHUB_PROFILE` (`src/data/site.ts`) — URL do perfil público do GitHub
- `TODO_URL_REPO_PORTFOLIO` (`site.ts`) — repositório deste site
- `TODO_OG_IMAGE` (`site.ts`) — imagem 1200x630 em `public/`
- `TODO_DOMINIO` — variável `SITE_URL` (domínio ou `*.pages.dev`)
- `TODO_STACK_CONFIRMADA` (`src/data/stack.ts`) — tecnologias que o Breno domina
- CRM Lava Jato (`src/content/projetos/crm-lava-jato.md`): `TODO_RESUMO_FUNCIONALIDADES`,
  `TODO_STACK_CRM`, `TODO_URL_DEMO_CRM`, `TODO_METRICA`, `TODO_PROBLEMA`, `TODO_DECISOES`,
  `TODO_RESULTADO`, `TODO_SCREENSHOT_CRM` (use `imagem` + `imagemAlt` no frontmatter; sem dados
  pessoais). Os marcadores de stack, demo e métrica também estão em `src/data/pendencias.ts`.
- Opcional: `cv` em `site.ts` (PDF em `public/`); sem ele o botão "Baixar CV" não aparece.

O repositório do CRM é **privado**: o site não exibe botão nem link de código para ele.

## Deploy (Cloudflare Pages)

Conecte o repositório pela integração Git: diretório raiz `site`, comando de build
`npm run build:prod` (produção) e saída `dist`. Defina `SITE_URL` nas variáveis do projeto e no
GitHub (Settings > Variables). Nenhum deploy foi feito.

## Uso de IA

Este site foi desenvolvido com apoio de agentes de IA, com revisão do Breno.
