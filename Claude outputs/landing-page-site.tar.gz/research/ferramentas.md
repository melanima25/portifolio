# Ferramentas e stack para o portfólio (pesquisa em 07/10/2026)

Legenda: **[Fato]** = dado da fonte; **[Inferência]** = minha conclusão.

## 1. Dados de mercado

- **[Fato]** Stack Overflow Developer Survey 2026 (publicada 06/10/2026, 30.903 respostas, 169 países): linguagens mais usadas são JavaScript, SQL, HTML/CSS, Python e Bash. 62% veem a IA com bons olhos e 70% usam agentes de IA. Freelance subiu de 3,9% para 10,5%. https://survey.stackoverflow.co/2026/
- **[Fato]** Na edição 2025: PostgreSQL 55,6%, Docker 71,1%, 79% usavam IA e 32,4% trabalhavam 100% remoto. Fonte: https://stackoverflow.blog/2026/09/30/getting-ready-for-2026-results-a-look-back-on-developer-survey-findings/
- **[Fato]** GitHub Octoverse 2025 (28/10/2025): TypeScript passou Python e JavaScript e virou a linguagem nº 1 do GitHub, com +66% de contribuidores. Cerca de 80% dos novos devs usam Copilot na primeira semana. https://github.blog/news-insights/octoverse/octoverse-a-new-developer-joins-github-every-second-as-ai-leads-typescript-to-1/
- **[Fato]** State of JS 2025 (18/03/2026, 13.002 respostas): React domina em uso. Astro lidera Next.js em satisfação por 39 pontos. Vite tem sentimento +55, contra -23 do webpack. Cerca de 29% do código gerado vem de IA. https://strapi.io/blog/state-of-javascript-2025-key-takeaways (resumo de terceiros; não li o relatório original).

## 2. Hospedagem gratuita

Fonte: https://agentdeals.dev/hosting-free-tier-comparison-2026 (atualizada em 30/09/2026; agregador de terceiros, confira nas páginas oficiais).

| Plataforma | Banda grátis | Uso comercial |
|---|---|---|
| GitHub Pages | ~100 GB/mês (limite brando) | Proibido para negócio/e-commerce |
| Vercel Hobby | 100 GB/mês | Só uso pessoal |
| Netlify | ~15 GB/mês (sistema de créditos) | Permitido |
| Cloudflare Pages | Ilimitada para estáticos; 500 builds/mês | Permitido |

**[Inferência]** Para um portfólio pessoal, qualquer uma serve. Cloudflare Pages tem os limites mais folgados e permite uso comercial, o que importa se você hospedar o CRM do lava jato, que é um projeto com cliente. Vercel Hobby e GitHub Pages podem violar os termos nesse caso.

## 3. Landing page: comparação

Fonte do comparativo Astro x Next.js: https://www.bitdoze.com/astro-vs-nextjs-vs-tanstack-start-which-wins-2026/ (10/07/2026). Os números de desempenho vêm de um blog, não de benchmark independente.

| Opção | Prós | Contras |
|---|---|---|
| HTML/CSS/JS puro | Zero build, rápido, mostra domínio dos fundamentos | Sem componentes, repetição, não demonstra ferramentas de mercado |
| React (Vite) | Mais usado, aparece em muitas vagas | Envia JS demais para uma página estática, SEO fraco sem SSR |
| Next.js | Full-stack, muito pedido em vagas | Excesso para uma landing page; **[Fato]** envia ~85-95 KB de JS numa página simples |
| Astro | **[Fato]** 0 KB de JS por padrão, lidera em satisfação, aceita componentes React | Menos vagas citam Astro diretamente |

### Recomendação: Astro + TypeScript + Tailwind, hospedado no Cloudflare Pages

**[Inferência]** Justificativas:
1. Um portfólio é conteúdo estático, e o Astro foi feito para isso (carrega rápido, Lighthouse alto, bom SEO).
2. Você escreve componentes e pode incluir uma "ilha" React, o que mostra React sem pagar o custo de JS em toda a página.
3. A curva de aprendizado é baixa e usa TypeScript, a linguagem nº 1 do GitHub.
4. Deploy por git push no Cloudflare Pages, sem custo.

Alternativa: se quiser o mínimo de risco e velocidade, HTML/CSS puro faz uma landing page boa. Perde só em demonstrar ferramental.

## 4. Stack ideal para os próximos projetos

**[Inferência]**, baseada nos dados acima e no seu objetivo de vaga remota júnior:

- **Linguagem:** TypeScript em tudo (front e back). Python como segunda linguagem, útil para automação e para seus indicadores do hospital.
- **Frontend:** React com Vite (maior demanda), mais Tailwind. Next.js só em um projeto full-stack para ter o nome no currículo.
- **Backend:** Node.js com Fastify ou Express, ou Next.js route handlers. Valide entradas com Zod.
- **Banco:** PostgreSQL (55,6% de uso em 2025), com Prisma ou Drizzle. Para hospedar de graça, Supabase ou Neon (confira os limites atuais antes de usar; não os pesquisei).
- **CI/CD:** GitHub Actions com lint, testes e deploy automático. Docker em pelo menos um projeto (71,1% de uso).
- **Testes:** Vitest e Playwright, sem exagero. Poucos testes bem feitos já diferenciam um júnior.
- **IA:** use Copilot ou Claude Code, mas saiba explicar cada linha. **[Fato]** 48% só confiam na IA quando conseguem verificar a saída; isso vale também para recrutadores. Registre no README como usou a IA.
- **Portfólio:** 3 a 4 projetos com README, demo no ar e testes. O CRM do lava jato em produção é seu melhor ativo; destaque-o primeiro.

## 5. Limitações

- Não achei dados específicos do mercado brasileiro de vagas remotas júnior; vale pesquisar em Gupy, LinkedIn e Remotar.
- Não abri o relatório original do State of JS nem a página oficial do Octoverse além do primeiro trecho; o resumo do SO 2026 veio de uma única página.
- Limites de planos gratuitos mudam com frequência; confirme antes de decidir.
