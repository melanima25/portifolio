# Pesquisa de vagas remotas júnior e freelas (2026)

Data da pesquisa: 2026-10-07. Limitação: buscas retornaram só títulos; li 4 páginas. Dados internacionais de vagas júnior específicas ficaram fracos (não verificados).

## 1. Stacks mais pedidas
**Fatos**
- Brasil, vagas remotas júnior (DevVagas, início de 2026, contagem aproximada da página): React (~40+ vagas), TypeScript, JavaScript, Node.js, Java, Python, .NET/C#, Angular, Vue, PHP. Combinações comuns: React + Node.js e .NET + Angular. Júnior = ~28% das vagas remotas. https://www.devvagas.com.br/vagas/remoto
- CrazyStack (18/03/2026), ranking de stacks para júnior: React/JS, Python, Java, Node/TS, mobile. Faixa remota PJ R$ 4.500–8.000/mês; internacional (1–2 anos) US$ 20–45/h. Fonte de blog, não oficial. https://www.crazystack.com.br/blog/quanto-ganha-desenvolvedor-junior-2026/
- Upwork (04/02/2026): em "Coding & Web", crescimento de AI Integration (+178%) e AI Chatbot Development (+71%). https://investors.upwork.com/news-releases/news-release-details/upworks-demand-skills-2026-demand-top-ai-skills-more-doubles-ai

**Inferência:** JavaScript/TypeScript (React + Node) é a aposta de maior volume para júnior remoto; Python é segunda por dados/automação/IA.

## 2. Serviços de freelas mais contratados
**Fatos**
- Workana (22/12/2025) lista como mais demandadas: web/mobile + IA aplicada (sites, apps, integrações/APIs, MVPs); UI/UX para conversão (landing pages); automação de marketing/CRM (Zapier etc.); assistente virtual com IA. https://blog.workana.com/pt/freelanceando-pt/as-5-habilidades-freelance-mais-demandadas-em-2026-para-conseguir-trabalho-remoto/
- Upwork: AI Integration, chatbots de IA e e-commerce em alta (ver acima).

**Inferência (sem número de volume por serviço; não encontrei):** ordem provável de demanda para júnior: sites/landing pages > automações e integrações (APIs, planilhas, WhatsApp) > CRMs/sistemas sob medida > dashboards > chatbots/IA. Sites são o mais saturado; automação e IA têm crescimento maior.

## 3. Habilidades comuns exigidas
- Fato (DevVagas): muitas vagas júnior anunciam "sem teste de algoritmo".
- Fato (Workana): combinar execução com uso de ferramentas de IA e resultado de negócio mensurável.
- Inferência (padrão geral de vagas, não medido aqui): Git/GitHub, SQL, APIs REST, TypeScript, noções de deploy/cloud, inglês técnico, comunicação assíncrona, uso de IA como ferramenta.

## 4. Cinco ideias de projeto de portfólio (inferência, mapeadas às demandas)
1. **CRM/gestão multiusuário v2** (evolução do CRM do lava jato): React + Node/TS + PostgreSQL, auth, deploy, testes. Cobre sistemas sob medida e a stack mais pedida. Já tem case em produção, destacar métricas.
2. **Dashboard de indicadores** (seu cenário hospitalar, com dados fictícios/anonimizados): upload de planilhas semanais por setor, consolidação mensal/anual, gráficos, exportação. Cobre dashboards, SQL e Python/pandas. Nunca usar dados reais de pacientes.
3. **Automação + integração**: bot que recebe dados (formulário/WhatsApp/e-mail), valida, grava em banco/Sheets e gera relatório; webhooks, APIs, filas simples. Cobre automações/integrações.
4. **Chatbot de IA com base de conhecimento (RAG)** para atendimento de um negócio (FAQ do lava jato/clínica): API de LLM, busca em documentos, painel de conversas. Cobre o nicho de maior crescimento (AI Integration/Chatbot).
5. **Site/landing page de conversão com formulário e analytics** para pequeno negócio local, com SEO, performance (Lighthouse) e integração com CRM. Cobre o serviço de entrada mais comum em Workana/99Freelas.

## Próximos passos sugeridos
Validar com buscas diretas em LinkedIn, Wellfound, Remote OK, Workana e 99Freelas (contagem por palavra-chave) para quantificar o que aqui é inferência.
