# Pesquisa de layouts: portfólio dev júnior (out/2026)

Legenda: [F] fato da fonte citada; [I] inferência minha.

## 1. Estrutura que recrutadores valorizam
- [F] Projetos completos e publicados valem mais que tutoriais clonados (weather app, to-do); 3 a 5 projetos bons superam 10 medianos. README que explica o porquê das decisões, histórico de commits iterativo. Fonte: Hyperskill, 08/06/2026 https://hyperskill.org/blog/post/building-a-developer-portfolio-in-2026-what-actually-gets-attention
- [F] Recrutadores escaneiam em segundos o que vem primeiro (título do guia "7 seconds"; não li o conteúdo). https://www.fueler.io/blog/your-portfolio-has-7-seconds-what-recruiters-look-at-first
- [F] Formatos que funcionam: perfil GitHub com README e pins, site minimalista de 1-2 páginas (Astro/Next + Tailwind, Vercel/Netlify), página de projeto com diagrama e decisões técnicas. Fonte: DevPlaybook, 20/03/2026 https://devplaybook.cc/blog/best-developer-portfolio-examples-2025
- [I] Para Breno: o CRM do lava jato em produção é o diferencial (cliente real); o contexto hospitalar (consolidação de indicadores) é história de resolução de problema real.

## 2. Estilos em alta
- [F] Bento grid (~45% de adoção), tipografia grande no lugar de imagem hero, dark mode como decisão de design, scroll-driven animations aceleradas, microinterações como UX, cores acessíveis desde o início, tipografia fluida com `clamp()`, brutalismo como reação a visual "genérico de IA", páginas leves. Fonte: Line25, 16/04/2026 (atualizado 23/04) https://line25.com/articles/web-design-trends-2026/
- [I] Glassmorphism está saturado; evitar para não parecer template.

## 3. Acessibilidade e performance
- [F, conhecimento prévio, não verificado nesta busca] Metas Core Web Vitals: LCP <= 2,5 s, INP <= 200 ms, CLS <= 0,1 (web.dev/vitals). WCAG 2.2 AA: contraste 4,5:1 em texto, foco visível, alvos de toque adequados.
- [I] Checklist: HTML semântico, `prefers-color-scheme` e `prefers-reduced-motion`, imagens WebP/AVIF com width/height, fontes self-hosted com `font-display: swap`, skip link, Lighthouse >= 95 como selo no rodapé.

## 4. Portfólios de referência (fonte: Elementor, 29/06/2026 https://elementor.com/blog/best-web-developer-portfolio-examples/)
- https://brittanychiang.com/ : página única organizada, projetos com links GitHub (melhor modelo para júnior)
- https://tamalsen.dev/ : minimalista, animações sutis
- https://jacek.hirsz.co/ : verde sobre escuro, identidade forte
- https://nerdy.dev/ : demos técnicas interativas
- https://www.joshwcomeau.com/ : microinterações e conteúdo
- https://lynnandtonic.com/ : redesign anual
- https://bruno-simon.com/ : 3D/WebGL (referência de ousadia; [I] fora de escopo para júnior)

## 5. Wireframe recomendado (página única, ordem)
1. Header fixo: nome, âncoras, toggle de tema, links LinkedIn/GitHub
2. Hero: "Desenvolvedor júnior | busco vaga remota", 1 frase de valor, CTAs (Ver projetos / Contato / CV)
3. Projetos em destaque (bento grid): CRM Lava Jato (produção, destaque grande), CRM Advocacia, demais; cada card com problema, stack, links demo+repo
4. Estudo de caso do projeto principal: problema, decisões, resultado, screenshot
5. Stack (ícones agrupados, só o que domina)
6. Sobre: trajetória (hospital, indicadores) e rumo à programação, 3-4 linhas
7. Contato: e-mail, LinkedIn, GitHub; rodapé

## 6. Três direções de estilo
A. **Dev Terminal Escuro**: fundo #0B0F14, texto #E6EDF3, acento verde #3DDC97; mono (JetBrains Mono) em títulos + Inter no corpo; bento com bordas finas, cursor piscando no hero.
B. **Claro Editorial**: fundo #FAF8F5, texto #1A1A1A, acento azul-cobalto #2B50FF; serifa grande (Fraunces) + sans; muito espaço, hover sutil. Mais "profissional", combina com perfil de saúde/negócios.
C. **Brutalista Colorido**: fundo creme, bordas pretas grossas, sombras duras, acento amarelo #FFD400 e rosa; tipografia gigante; destaca-se de templates, risco de ser pesado.

[I] Recomendação: A com toggle para tema claro; mais comum no meio dev, fácil de manter acessível.

Limitação: o WebSearch retornou só títulos/URLs; conteúdo vem dos WebFetch citados. Não verifiquei contraste das paletas.
