# Pesquisa de conteúdo: LinkedIn + GitHub (pesquisa em 2026-10-07)

Legenda: **[F]** fato citado na fonte; **[I]** inferência minha. Fontes de blog/marketing são correlacionais e não vêm do LinkedIn; trate como indícios.

## 1. LinkedIn

- **[F] Carrossel (PDF) é o formato com mais engajamento.** Buffer, 2+ milhões de posts, publicado em 28/08/2025: carrossel com cerca de 278% mais engajamento que vídeo e cerca de 600% mais que texto. https://buffer.com/resources/how-often-to-post-on-linkedin/
- **[F] Teste de 300 posts:** PDF carrossel em 1º lugar; texto puro com gancho forte rende mais alcance por seguidor; imagem única tem 30% menos alcance que texto. Primeiros 60 minutos de engajamento decidem a distribuição; comentários longos pesam mais que curtidas. https://rivereditor.com/blogs/2026-linkedin-algorithm-what-works-300-posts-tested (data da página não confirmada)
- **[F] Links externos:** a fonte acima diz cerca de 60% menos alcance. Outra matéria cita 60%, mas também uma análise com queda mediana de 18,8%; diz que o link no comentário também seria penalizado no início de 2026. A recomendação é conteúdo "zero-click". https://www.agilitypr.com/pr-news/social-media-influencer-marketing/the-linkedin-link-tax-why-sharing-your-blog-is-costing-you-60-percent-of-your-audience/ (a magnitude varia bastante entre estudos)
- **[F] Frequência:** Buffer indica 2-5 posts/semana como ponto ideal; o teste de 300 posts indica 3-4 por semana, de terça a quinta, evitando 12h-14h.
- **[F] Hashtags:** 3-5 (ou 1-2). Mais hashtags aumentam a taxa de engajamento, mas reduzem impressões (média de 2.269 contra 6.632 sem hashtag). https://www.tryordinal.com/blog/linkedin-hashtags (data não clara, parece 2026)
- **[I]** Para um júnior com poucos seguidores, o objetivo é ser visto por recrutadores. Por isso: 3 posts/semana, 2-3 hashtags de nicho (#dev, #javascript), link do repositório só no perfil e no "Em destaque", ou no primeiro comentário depois do engajamento inicial. Se o link no comentário for penalizado, o fallback é pôr o link no perfil e responder por DM a quem pedir.
- **[I]** Formatos que servem a projeto de portfólio: carrossel "problema, solução, stack, aprendizado"; antes/depois (tela ou código); build in public (relato semanal curto). Não achei estudo específico sobre devs júnior, então não há dado direto sobre o que funciona melhor para eles.

## 2. GitHub (documentação oficial)

- **[F] README de perfil:** repositório público com o mesmo nome do usuário e um README.md com conteúdo. https://docs.github.com/en/account-and-profile/setting-up-and-managing-your-github-profile/customizing-your-profile/managing-your-profile-readme
- **[F] Pinned:** até 6 itens (repositórios e gists). https://docs.github.com/en/account-and-profile/setting-up-and-managing-your-github-profile/customizing-your-profile/pinning-items-to-your-profile
- **[F] Contribuições:** só contam commits com e-mail vinculado à conta, na branch padrão ou gh-pages (feature branch só depois do merge); commits em fork não contam; pode levar até 24 horas. https://docs.github.com/en/account-and-profile/setting-up-and-managing-your-github-profile/managing-contribution-settings-on-your-profile/why-are-my-contributions-not-showing-up-on-my-profile
- **[I]** Commits pequenos e frequentes, com mensagens claras (ex.: `feat: ...`, `fix: ...`), contam melhor a história do que um commit gigante. Não encontrei fonte sólida de 2026 sobre isso, então é prática comum, não dado.
- **[I]** GitHub Pages com demo ao vivo no topo do README reduz o atrito para o recrutador. Não pesquisei a documentação do Pages nesta rodada.
- **Lacuna:** não encontrei dado confiável sobre como recrutadores avaliam README ou gráfico de contribuições.

## 3. Calendário de 4 semanas (3 posts + commits por semana)

Considera 4 projetos; ajuste conforme os reais (ex.: CRM do lava jato, CRM de advocacia).

| Semana | Foco | Terça | Quarta | Quinta | Commits |
|---|---|---|---|---|---|
| 1 | Base | Texto: quem sou e meta (dev júnior remoto, vindo da área hospitalar) | Carrossel: projeto A (problema, solução, stack) | Build in public: o que aprendi | Criar README de perfil; README do projeto A; fixar 6 repos; 4-5 commits/semana |
| 2 | Projeto A em profundidade | Antes/depois de uma tela | Texto: um bug e como resolvi | Carrossel: arquitetura | Ativar GitHub Pages do A; commits de refatoração e testes |
| 3 | Projeto B | Texto: por que construí o B | Carrossel: B | Build in public: semana de trabalho | README do B com demo; issues e commits pequenos |
| 4 | Consolidação | Carrossel: "3 lições dos 2 projetos" | Texto: o que melhorar a seguir | Chamada: aberto a vagas remotas (sem link, contato por DM) | Revisar READMEs, pins e perfil; manter commits |

Regras: publicar ter-qui, fora de 12h-14h; responder todos os comentários na primeira hora; 2-3 hashtags.

## 4. Template de post

```
[GANCHO, 1 linha com resultado ou dor concreta]
(ex.: "Meu CRM economiza 2h por dia de uma equipe de lava jato.")

Contexto: [1-2 linhas, quem usa e qual problema]
O que fiz: [3 bullets curtos]
Stack: [tecnologias]
O que errei / aprendi: [1-2 linhas honestas]

Pergunta final para gerar comentário: [ex.: "Como você resolveria X?"]
Repo e demo: no meu perfil / "Em destaque".
#dev #javascript #portfolio
```

## 5. Template de README

```
# Nome do projeto
Uma frase: o que faz e para quem.
[Demo ao vivo] · [Screenshot ou GIF]

## Problema e solução
## Funcionalidades (bullets)
## Stack
## Como rodar (passos copiáveis: clone, install, env, start)
## Decisões técnicas e aprendizados
## Próximos passos
## Contato
```

## Sugestão de memória (para a sessão principal)

Objetivo de conteúdo do Breno: 3 posts/semana no LinkedIn com carrossel e build in public, links só no perfil, e 6 repositórios fixados no GitHub.
